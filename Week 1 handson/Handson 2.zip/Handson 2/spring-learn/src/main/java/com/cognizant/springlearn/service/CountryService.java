package com.cognizant.springlearn.service;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

public class CountryService {
	public static Country getCountry(String code)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
    	ArrayList<Country> country =new ArrayList<Country>();
    	 country = context.getBean("countryList", java.util.ArrayList.class);
    	 int a=1;
         for(Country g : country) {
             if(g.getCode().equalsIgnoreCase(code))
             {
            	 a=0;
                return g;
             }
         }
    	 if(a==1)
    	 {
    		 throw new CountryNotFoundException();
    	 }
        
		return null;
        
	}
}

