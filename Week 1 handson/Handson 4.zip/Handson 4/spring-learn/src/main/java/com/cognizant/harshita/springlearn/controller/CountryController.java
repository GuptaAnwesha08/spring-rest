package com.cognizant.harshita.springlearn.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.harshita.springlearn.Country;

@RestController
public class CountryController {
	@Autowired
	private CountryService country;
	@GetMapping("/country")
	public ArrayList<Country> retrieveAllCountry(){
		return country.allCountry();
	}
	
	@GetMapping("/country/{code}")
	public Country retriveCountry(@PathVariable String code) {
		return country.findOneCountry(code);
	}

	@PostMapping("/country")
	public void addCountry(@RequestBody ArrayList<Country> countryList) {
		country.save(countryList);
		
	}

}
