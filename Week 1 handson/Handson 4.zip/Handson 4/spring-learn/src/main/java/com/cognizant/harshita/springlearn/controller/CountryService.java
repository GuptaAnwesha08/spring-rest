package com.cognizant.harshita.springlearn.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.harshita.springlearn.Country;

@Component
public class CountryService {
	ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
	   ArrayList<Country> countryList = (ArrayList<Country>) context.getBean("countryList",ArrayList.class);
	
	public ArrayList<Country> allCountry() {
//		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
//		   ArrayList<Country> countryList = (ArrayList<Country>) context.getBean("countryList",ArrayList.class);
		return countryList;
	}

	public Country findOneCountry(String code) {
		 for(Country c:countryList) {
			 if(c.getCode().equalsIgnoreCase(code)) {
				 return c;
			 }
		 }
		 return null;
	}
	
	public ArrayList<Country> save(ArrayList<Country> countryList) {
		countryList.addAll(countryList);
		return countryList;
		
	}
	
	
	
	
	
}