package com.cognizant.harshita.springlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
