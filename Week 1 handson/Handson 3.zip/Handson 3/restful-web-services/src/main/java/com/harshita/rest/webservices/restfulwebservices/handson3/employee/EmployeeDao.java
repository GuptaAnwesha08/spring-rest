package com.harshita.rest.webservices.restfulwebservices.handson3.employee;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class EmployeeDao {

	private static ArrayList<Employee> emp=new ArrayList<>();
	
	static {
		emp.add(new Employee(1,"Harshita"));
		emp.add(new Employee(2,"Harshita"));
		emp.add(new Employee(3,"Harshita"));
		emp.add(new Employee(4,"Harshita"));
	}
	
	public List<Employee> getAllEmployees(){  //return all 	emp
		return emp;
	}
	
	
}
