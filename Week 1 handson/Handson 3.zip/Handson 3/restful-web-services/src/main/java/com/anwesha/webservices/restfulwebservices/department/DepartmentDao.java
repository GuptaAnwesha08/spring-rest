package com.anwesha.webservices.restfulwebservices.department;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
@Component
public class DepartmentDao {
private static ArrayList<Department> department=new ArrayList<>();
	
	static {
		department.add(new Department(1,"CS"));
		department.add(new Department(2,"IT"));
		department.add(new Department(3,"EC"));
		department.add(new Department(4,"EE"));
		
	}
	
	public ArrayList<Department> getAllDepartment(){  
		return department;
	}
	
	
	
	
}
