package com.harshita.rest.webservices.restfulwebservices.handson3.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDao employeeDao;
	
	@Transactional
	public List<Employee>getAllEmployees(){
		return employeeDao.getAllEmployees();
	}

}
