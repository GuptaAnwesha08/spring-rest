package com.harshita.rest.webservices.restfulwebservices.handson3.department;

import java.util.ArrayList;

import org.springframework.stereotype.Component;
@Component
public class DepartmentDao {
private static ArrayList<Department> department=new ArrayList<>();
	
	static {
		department.add(new Department(1,"CS"));
		department.add(new Department(1,"IT"));
		department.add(new Department(1,"EC"));
		department.add(new Department(1,"CIVIL"));
		
	}
	
	public ArrayList<Department> getAllDepartment(){  //return all 	department
		return department;
	}
	
	
	
	
}
