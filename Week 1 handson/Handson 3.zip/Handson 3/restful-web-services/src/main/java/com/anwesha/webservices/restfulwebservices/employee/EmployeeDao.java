package com.anwesha.webservices.restfulwebservices.employee;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class EmployeeDao {

	private static ArrayList<Employee> emp=new ArrayList<>();
	
	static {
		emp.add(new Employee(1,"Anw"));
		emp.add(new Employee(2,"Ayu"));
		emp.add(new Employee(3,"Abc"));
		emp.add(new Employee(4,"def"));
	}
	
	public List<Employee> getAllEmployees(){  
		return emp;
	}
	
	
}
