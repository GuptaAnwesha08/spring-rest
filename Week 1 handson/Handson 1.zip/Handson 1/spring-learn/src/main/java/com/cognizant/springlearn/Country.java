package com.cognizant.springlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {

	String code;
	String name;
	private static final Logger LOGGER=LoggerFactory.getLogger(Country.class);
	
	public String getCode() {
		LOGGER.info("get code:"+code);
		return code;
	}
	public void setCode(String code) {
		
		this.code = code;
		LOGGER.info("setCode:"+code);
	}
	public String getName() {
		LOGGER.info("getName:"+name);
		return name;
	}
	public void setName(String name) {
		
		this.name = name;
		LOGGER.info("setName:"+name);
	}
	public Country() {
		super();
		// TODO Auto-generated constructor stub
		LOGGER.info("Inside Country Constructor");
	}
	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}
	
	
}
