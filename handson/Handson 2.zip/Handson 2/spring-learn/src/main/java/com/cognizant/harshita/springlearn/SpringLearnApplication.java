package com.cognizant.harshita.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class SpringLearnApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(SpringLearnApplication.class, args);
		System.out.println("Hello World");
		displayDate();
		displayCountry();
		displayCountries();
	}
	public static void	displayDate(){
		LOGGER.info("START");
		 ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
		 SimpleDateFormat format = context.getBean("dateFormat", SimpleDateFormat.class);
		 try {
			System.out.println(format.parse("31/12/2018"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 LOGGER.info("END");
			
		}
	
   public static void displayCountry() {
	   ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
	   Country country = (Country) context.getBean("country",Country.class);
	   Country anotherCountry = context.getBean("country", Country.class);
	   LOGGER.debug("Country : {}", country.toString());
	   System.out.println(country);
         System.out.println(country.hashCode());
         System.out.println(anotherCountry);
         System.out.println(anotherCountry.hashCode());
	   
   }
   
  public static void displayCountries() {
	  ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
	   ArrayList<Country> countryList = (ArrayList<Country>) context.getBean("countryList",ArrayList.class);
	 //  Country anotherCountry = context.getBean("country", Country.class);
	   System.out.println(countryList);
	   for(Country c:countryList)
	   LOGGER.debug("Country : {}", countryList.toString());
  }
		
	
}