package com.cognizant.harshita.springlearn.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CountryController {
	


}
