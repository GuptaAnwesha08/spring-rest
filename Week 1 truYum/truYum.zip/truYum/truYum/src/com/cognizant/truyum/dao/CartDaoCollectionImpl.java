package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import com.cognizant.truyum.model.MenuItem;

import com.cognizant.truyum.model.Cart;

public class CartDaoCollectionImpl implements CartDao {
	private static HashMap<Long, Cart> userCarts;

	public CartDaoCollectionImpl() {
		super();
		// TODO Auto-generated constructor stub
		if(userCarts == null) {
			userCarts = new HashMap<Long, Cart>();
//			Cart cart = new Cart();
//			cart.setTotal(10.0);
//			MenuItemDaoCollectionImpl m = new MenuItemDaoCollectionImpl();
//			List<MenuItem> menuItemList = m.getMenuItemListAdmin();
//			cart.setMenuItemList(menuItemList);
//			tempCart.put((long) 1, cart);
//			userCarts = tempCart;
		}
	}

	public void addCartItem(long userId, long menuItemId) {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		//System.out.println(menuItem);
		if(userCarts.containsKey(userId)) {
			 userCarts.get(userId).getMenuItemList().add(menuItem);
			
		} else {
			Cart cart = new Cart();
			List<MenuItem> list = new ArrayList<MenuItem>();
			list.add(menuItem);
			cart.setMenuItemList(list);
			userCarts.put(userId, cart);
		}
	}

	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
		Cart cart = userCarts.get(userId);
		
		List<MenuItem> menuItemList  = cart.getMenuItemList();
		if(menuItemList.isEmpty()) {
			throw new CartEmptyException();
		} else {
			Double total = (double) 0;
			for(int i = 0; i < menuItemList.size(); i++) {
				total += menuItemList.get(i).getPrice();
			}
			//Cart c = new Cart();
			cart.setTotal(total);
			return cart.getMenuItemList();
		}
	}

	public void removeCartItem(long userId, long menuItemId) {
		Cart cart = userCarts.get(userId);
		ListIterator<MenuItem> listIterator = cart.getMenuItemList().listIterator();
		while(listIterator.hasNext()) {
			if(listIterator.next().getId() == menuItemId) {
				listIterator.remove();
			}
		}
	}
}
