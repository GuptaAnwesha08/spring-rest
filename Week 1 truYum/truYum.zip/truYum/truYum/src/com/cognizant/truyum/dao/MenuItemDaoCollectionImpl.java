package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao {
	private static List<MenuItem> menuItemList;

	public MenuItemDaoCollectionImpl() {
		super();
		if (menuItemList == null) {
			menuItemList = new ArrayList<>();
			MenuItem mi1 = new MenuItem(1, "Sandwich", 99, true, DateUtil.convertToDate("15/03/2017"), "Main Course",
					true);
			menuItemList.add(mi1);
			MenuItem mi2 = new MenuItem(2, "Burger", 129, true, DateUtil.convertToDate("23/12/2017"), "Main Course",
					false);
			menuItemList.add(mi2);
			MenuItem mi3 = new MenuItem(3, "Pizza", 149, true, DateUtil.convertToDate("21/08/2018"), "Main Course",
					false);
			menuItemList.add(mi3);
			MenuItem mi4 = new MenuItem(4, "French Fries", 57, false, DateUtil.convertToDate("02/07/2017"), "Starters",
					true);
			menuItemList.add(mi4);
			MenuItem mi5 = new MenuItem(5, "Chocolate", 32, true, DateUtil.convertToDate("02/11/2022"), "Dessert",
					true);
			menuItemList.add(mi5);
		}
	}

	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	public List<MenuItem> getMenuItemListCustomer() {
		List<MenuItem> l = new ArrayList<>();
		Date d = new Date();
		for (int i = 0; i < menuItemList.size(); i++) {
			if ((menuItemList.get(i).getDateOfLaunch().before(d)) && (menuItemList.get(i).isActive())) {
				l.add(menuItemList.get(i));
			}
		}
		return l;
	}

	public void modifyMenuItem(MenuItem menuItem) {
		//Add Customer submit user form logic
		for (int i = 0; i < menuItemList.size(); i++) {
			if(menuItemList.get(i).getId()	==	(menuItem.getId())) {
				menuItemList.set(i, menuItem);
			}
		}
	}

	public MenuItem getMenuItem(long menuItemId) {
		//Add logic to Edit link
		for (int i = 0; i < menuItemList.size(); i++) {
			if(menuItemList.get(i).getId() == menuItemId) {
				return menuItemList.get(i);
			}
		}
		return null;
	}
}
