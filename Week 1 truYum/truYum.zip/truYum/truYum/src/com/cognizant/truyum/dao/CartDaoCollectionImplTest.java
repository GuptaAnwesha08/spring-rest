package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {
	public static void main(String args[]) throws CartEmptyException {
		CartDaoCollectionImplTest.testAddCartItem();
		CartDaoCollectionImplTest.testGetAllCartItems();
		CartDaoCollectionImplTest.testRemoveCartItem();
	}

	private static void testRemoveCartItem() {
		// TODO Auto-generated method stub
		CartDao cartDao = new CartDaoCollectionImpl();
		try {
			cartDao.removeCartItem(2, 2);
			cartDao.removeCartItem(2, 3);
			//cartDao.getAllCartItems(2);
			System.out.println(cartDao.getAllCartItems(2).toString());
		} catch (CartEmptyException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Cart is Empty!.....");
		}
	}

	private static void testGetAllCartItems() throws CartEmptyException {
		// TODO Auto-generated method stub
		CartDao cartDao = new CartDaoCollectionImpl();
		List<MenuItem> menuItemList = cartDao.getAllCartItems(2);
		// for (int i = 0; i < menuItemList.size(); i++) {
		 System.out.println(menuItemList);
		// }
	}

	private static void testAddCartItem() throws CartEmptyException {
		// TODO Auto-generated method stub
		CartDao cartDao = new CartDaoCollectionImpl();
		cartDao.addCartItem(2, 3);
		cartDao.addCartItem(2, 2);
		List<MenuItem> menuItemList = cartDao.getAllCartItems(2);
		// for (int i = 0; i < menuItemList.size(); i++) {
		// System.out.println(menuItemList.toString());
		// }
		for (MenuItem menuItem : menuItemList) {
			System.out.println(menuItem);
		}

	}
}
