package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemService {
    @Autowired
	private MenuItemDaoCollectionImpl m;
	
	public List<MenuItem> getMenuItemListCustomer() {
		return m.getMenuItemListCustomer();
		
	}
	
    	public MenuItem getMenuItem(long menuItemId){
	   return m.getMenuItem(menuItemId);
	}
   
    public 	void modifyMenuItem(MenuItem menuItem){
     	m.modifyMenuItem(menuItem);
    		
    	}
    	

}
