package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cognizant.truyum.model.MenuItem;
@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao {
	//private static List<MenuItem> menuItemList;

	ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml");
	 ArrayList<MenuItem> menuItemList  = (ArrayList<MenuItem>)context.getBean("menuItemList",ArrayList.class);
	
//	public MenuItemDaoCollectionImpl() {
//		super();
//		if (menuItemList == null) {
//			
//		}
//	}

	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	public List<MenuItem> getMenuItemListCustomer() {
//		List<MenuItem> l = new ArrayList<>();
//		Date d = new Date();
//		for (int i = 0; i < menuItemList.size(); i++) {
//			if ((menuItemList.get(i).getDateOfLaunch().before(d)) && (menuItemList.get(i).isActive())) {
//				l.add(menuItemList.get(i));
//			}
//		}
		return menuItemList;
	}

	public void modifyMenuItem(MenuItem menuItem) {
		//Add Customer submit user form logic
		for (int i = 0; i < menuItemList.size(); i++) {
			if(menuItemList.get(i).getId()	==	(menuItem.getId())) {
				menuItemList.set(i, menuItem);
			}
		}
	}

	public MenuItem getMenuItem(long menuItemId) {
		//Add logic to Edit link
		for (int i = 0; i < menuItemList.size(); i++) {
			if(menuItemList.get(i).getId() == menuItemId) {
				return menuItemList.get(i);
			}
		}
		return null;
	}
}
