package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;

import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;
@Component
public class CartDaoCollectionImpl implements CartDao {
	private static HashMap<String, Cart> userCarts;

	public CartDaoCollectionImpl() {
		super();
		// TODO Auto-generated constructor stub
		if(userCarts == null) {
			userCarts = new HashMap<String, Cart>();
			//Cart cart = new Cart();
//			cart.setTotal(10.0);
//			MenuItemDaoCollectionImpl m = new MenuItemDaoCollectionImpl();
//			List<MenuItem> menuItemList = m.getMenuItemListAdmin();
//			cart.setMenuItemList(menuItemList);
//			tempCart.put((long) 1, cart);
//			userCarts = tempCart;
		}
	}

	public void addCartItem(String userId, long menuItemId) {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		//System.out.println(menuItem);
		if(userCarts.containsKey(userId)) {
			 userCarts.get(userId).getMenuItemList().add(menuItem);
			
		} else {
			Cart cart = new Cart();
			List<MenuItem> list = new ArrayList<MenuItem>();
			list.add(menuItem);
			cart.setMenuItemList(list);
			userCarts.put(userId, cart);
			//System.out.println(userCarts);
		}
	}

	public List<MenuItem> getAllCartItems(String userId) throws CartEmptyException {
		//System.out.println(userId);
		//System.out.println(userCarts.containsKey(userId));
		System.out.println(userCarts);
		Cart cart = userCarts.get(userId);
		
		List<MenuItem> menuItemList  = cart.getMenuItemList();
		//System.out.println(menuItemList);
	
		if(menuItemList.isEmpty()) {
			throw new CartEmptyException();
		} else {
			Double total = (double) 0;
			for(int i = 0; i < menuItemList.size(); i++) {
				total += menuItemList.get(i).getPrice();
			}
			//Cart c = new Cart();
			cart.setTotal(total);
			return cart.getMenuItemList();
		}
	}

	public void removeCartItem(long userId, long menuItemId) {
		Cart cart = userCarts.get(userId);
		ListIterator<MenuItem> listIterator = cart.getMenuItemList().listIterator();
		while(listIterator.hasNext()) {
			if(listIterator.next().getId() == menuItemId) {
				listIterator.remove();
			}
		}
	}

//	@Override
//	public void addCartItem(long userId, long menuItemId) {
//		// TODO Auto-generated method stub
//		
//	}
}
