package com.cognizant.truyum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

@RestController
public class MenuItemController {
	@Autowired
	private MenuItemService service;
	
	@GetMapping("/menu")
	public  List<MenuItem> getAllMenuItems(){
	return service.getMenuItemListCustomer();
		
	}
	
	@GetMapping("menu/{menuItemId}")
	public MenuItem getMenuItem(@PathVariable long menuItemId) {
		return service.getMenuItem(menuItemId);
		
	}
	
	@PutMapping("/menus")
	public void modifyMenuItem(@RequestBody MenuItem menuItem){
		service.modifyMenuItem(menuItem);
		 
	 }

}
