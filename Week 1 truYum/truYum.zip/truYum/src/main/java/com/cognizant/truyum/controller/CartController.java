package com.cognizant.truyum.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.CartService;
@RestController
public class CartController {
	@Autowired
	private CartService cartservice;
	
	 @PostMapping("cart/{userId}/{menuItemId}")
	public void addCartItem(@RequestBody String userId,@PathVariable long menuItemId){
		 cartservice.addCartItem(userId, menuItemId);
		 
	 }
	 
	 @GetMapping("/cart/{userId}")
	public List<MenuItem> getAllCartItems(@PathVariable String userId) throws CartEmptyException{
		return cartservice.getAllCartItems(userId);
		 
	 }
	

}
