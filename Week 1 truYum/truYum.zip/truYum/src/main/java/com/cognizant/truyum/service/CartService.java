package com.cognizant.truyum.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.dao.CartDaoCollectionImpl;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

@Component
public class CartService {
    @Autowired
	private CartDaoCollectionImpl c;
    
  public void addCartItem(String userId, long menuItemId){
    	c.addCartItem(userId, menuItemId);
    }
  
 public List<MenuItem> getAllCartItems(String userId) throws CartEmptyException{
	 return c.getAllCartItems(userId);
  }
	 
}
