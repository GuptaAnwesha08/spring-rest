package com.cognizant.truyum;

import java.util.ArrayList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.truyum.dao.CartDaoCollectionImpl;
import com.cognizant.truyum.dao.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;

@SpringBootApplication
public class TruyumApplication {
	public static void main(String[] args) throws CartEmptyException {
		SpringApplication.run(TruyumApplication.class, args);
		System.out.println("Hello");
		ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml");
		 ArrayList<MenuItem> menuItemList  = (ArrayList<MenuItem>)context.getBean("menuItemList",ArrayList.class);
		//System.out.println(menuItemList);
		//CartDaoCollectionImpl c=new CartDaoCollectionImpl();
		//c.addCartItem("2", 1);
		//System.out.println(usercarts);
		//System.out.println(c.getAllCartItems("2"));
		//c.addCartItem("3", 2);
	}


}
