package com.cognizant.account;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {
	
	@GetMapping("/accounts/{number}")
	public String getAccount() {
		return "{ number: \"12345678901234\", type: \"savings\", balance: 238264 }";
	}

}
