package com.cognizant.movieCruiser.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieCruiser.model.Movie;
import com.cognizant.movieCruiser.service.MovieService;

@RestController
public class MovieController {

	@Autowired
	private MovieService service;
	
	@GetMapping("/movie/admin")
	public List<Movie> getAllMovie(){
		return service.getMovieListAdmin();
	}
	
	@GetMapping("/movie/customer")
	public List<Movie> getAllMovieCustomer(){
		return service.getMovieListCustomer();
	}
	
	@PutMapping("/movie/admin/edit")
	public void modifyMovie(@RequestBody Movie movie) {
		service.modifyMovie(movie);
	}
	
	
}
