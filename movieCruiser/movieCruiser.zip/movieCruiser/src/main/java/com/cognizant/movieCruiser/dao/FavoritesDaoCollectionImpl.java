package com.cognizant.movieCruiser.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.movieCruiser.model.Favorites;
import com.cognizant.movieCruiser.model.Movie;
@Component
public class FavoritesDaoCollectionImpl implements FavoritesDao {
	
	private static HashMap<String,Favorites> userFavorites;;
	
	
	
	
//	public void addFavoritesMovie(String userId, int movieId) {
//		MovieDao movieDao=new MovieDaoCollectionImpl();
//		System.out.println(movieDao);
//		Movie movie =movieDao.getMovieById(movieId);
//		System.out.println(movie);
//		if(customerFav.containsKey(userId)) {
//			customerFav.get(userId).getMovie().add(movie);
//			System.out.println(customerFav);
//		}
//		else {
//			Favorites fav=new Favorites();
//			List<Movie> list=new ArrayList<Movie>();
//			list.add(movie);
//		    fav.setMovie(list);
//		    customerFav.put(userId,fav);
//		}
//		
//	}
	
	
	public FavoritesDaoCollectionImpl() {
		super();
		// TODO Auto-generated constructor stub
		if(userFavorites==null) {
			userFavorites=new HashMap<String, Favorites>();
		}
	}

	//@Override
	public void addFavoritesMovie(String userId, int movieId) {
		MovieDao movieDao = new MovieDaoCollectionImpl();
		Movie movie = movieDao.getMovieById(movieId);
//System.out.println(movie);
//System.out.println(userFavorites);
		if (userFavorites.containsKey(userId)) {
			List<Movie> movieList = userFavorites.get(userId).getMovie();
			movieList.add(movie);
		} else {
			Favorites favorites = new Favorites();
			List<Movie> list=new ArrayList<Movie>();
		list.add(movie);
		favorites.setMovie(list);
		
			userFavorites.put(userId, favorites);
			//System.out.println(userFavorites);
			
		}
	}
	
	public List<Movie> getAllFavoritesMovies(String userId) throws FavoritesEmptyException{
		//System.out.println(userFavorites.get(userId));
		Favorites fav=userFavorites.get(userId);
		//System.out.println(fav);
		List<Movie> movie=fav.getMovie();
		if(movie.isEmpty()) {
			throw new FavoritesEmptyException();
		}
		else {
			return fav.getMovie();
		}
	}
	
	
//	//@Override
//	public List<Movie> getAllFavoritesMovies(long userId) throws FavoritesEmptyException {
//		if (userFavorites.containsKey(userId)) {
//			List<Movie> movieList = userFavorites.get(userId).getMovieList();
//			if (movieList.isEmpty()) {
//				throw (new FavoritesEmptyException());
//			} else {
//				userFavorites.get(userId).setNoOfFavorites(movieList.size());
//			}
//			return movieList;
//		} else {
//			throw (new FavoritesEmptyException());
//		}
//	}
	
	

	public void removeFavoritesMovie(String userId, int movieId) {
		List<Movie> movieList = userFavorites.get(userId).getMovie();
		for (int i = 0; i < movieList.size(); i++) {
			if (movieList.get(i).getId() == movieId) {
				movieList.remove(i);
				break;
			}
	}
	}
	

}
