package com.cognizant.movieCruiser.model;

import java.util.List;

public class Favorites {

	private List<Movie> movie;
	private int id;

	private int us_id;

	private int mv_id;

	public List<Movie> getMovie() {
		return movie;
	}

	public void setMovie(List<Movie> movie) {
		this.movie = movie;
	}

	public Favorites() {
		super();
	}

	public Favorites(int us_id, int mv_id) {
		super();
		this.us_id = us_id;
		this.mv_id = mv_id;
	}

	public Favorites(int id, int us_id, int mv_id) {
		super();
		this.id = id;
		this.us_id = us_id;
		this.mv_id = mv_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUs_id() {
		return us_id;
	}

	public void setUs_id(int us_id) {
		this.us_id = us_id;
	}

	public int getMv_id() {
		return mv_id;
	}

	public void setMv_id(int mv_id) {
		this.mv_id = mv_id;
	}

}
