package com.cognizant.movieCruiser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.movieCruiser.dao.FavoritesEmptyException;

@SpringBootApplication
public class MovieCruiserApplication {

	public static void main(String[] args) throws FavoritesEmptyException {
		SpringApplication.run(MovieCruiserApplication.class, args);
		System.out.println("Hello Movie");
	//	FavoritesDaoCollectionImpl f=new FavoritesDaoCollectionImpl();
		//f.addFavoritesMovie("1", 1);
		//System.out.println(f.getAllFavoritesMovies("1"));
	}

}
