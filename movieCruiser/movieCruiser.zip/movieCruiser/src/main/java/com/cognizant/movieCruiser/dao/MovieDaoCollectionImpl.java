package com.cognizant.movieCruiser.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.movieCruiser.model.Movie;
@Component
public class MovieDaoCollectionImpl implements MovieDao {
	
	ApplicationContext context = new ClassPathXmlApplicationContext("movieCruiser.xml");
	 ArrayList<Movie> movieList = (ArrayList<Movie>)context.getBean("movieList",ArrayList.class);
	
	 public List<Movie> getMovieListAdmin() {
			return movieList;
		}

		public List<Movie> getMovieListCustomer() {
			List<Movie> customerMovieList = new ArrayList<Movie>();

			for (int i = 0; i < movieList.size(); i++) {
				Movie movie = movieList.get(i);
				if ((movie.getDateOfLaunch().equals(new Date()) 
						|| movie.getDateOfLaunch().before(new Date())) && movie.isActive()) {
					customerMovieList.add(movie);
				}
			}

			return customerMovieList;
		}
		public void modifyMovie(Movie movie) {
			for (int i = 0; i < movieList.size(); i++) {
				if (movieList.get(i).equals(movie)) {
					movieList.set(i, movie);
					break;
				}
			}
		}
	public Movie getMovieById(int id) {
		for(int i=0;i<movieList.size();i++) {
			if(movieList.get(i).getId()==id) {
				return movieList.get(i);
			}
				
		}
		return null;
		
	}
	
}
