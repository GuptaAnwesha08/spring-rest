package com.cognizant.movieCruiser.dao;

import java.util.List;

import com.cognizant.movieCruiser.model.Movie;

public interface FavoritesDao {
	public void addFavoritesMovie(String userId, int movieId);
	public List<Movie> getAllFavoritesMovies(String userId) throws FavoritesEmptyException;

}
