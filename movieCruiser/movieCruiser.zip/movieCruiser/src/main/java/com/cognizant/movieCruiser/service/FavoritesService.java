package com.cognizant.movieCruiser.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.movieCruiser.dao.FavoritesDaoCollectionImpl;
import com.cognizant.movieCruiser.dao.FavoritesEmptyException;
import com.cognizant.movieCruiser.model.Movie;

@Component
public class FavoritesService {
	@Autowired
	private FavoritesDaoCollectionImpl f;
	
	
	public void addFavoritesMovie(String userId, int movieId) {
		f.addFavoritesMovie(userId, movieId);
	}

	public List<Movie> getAllFavoritesMovies(String userId) throws FavoritesEmptyException{
		return f.getAllFavoritesMovies(userId);
	}
	
	
	public void removeFavoritesMovie(String userId, int movieId) {
		f.removeFavoritesMovie(userId, movieId);
	}
	
	
}
