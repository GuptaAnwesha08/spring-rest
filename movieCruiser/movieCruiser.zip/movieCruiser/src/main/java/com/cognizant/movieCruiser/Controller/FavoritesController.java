package com.cognizant.movieCruiser.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movieCruiser.dao.FavoritesEmptyException;
import com.cognizant.movieCruiser.model.Movie;
import com.cognizant.movieCruiser.service.FavoritesService;

@RestController
public class FavoritesController {
	
	@Autowired
	private FavoritesService service;
	
	@PostMapping("/fav/{userId}/{movieId}")
	public void addFavoritesMovie(@RequestBody String userId,@PathVariable int movieId) {
		service.addFavoritesMovie(userId, movieId);
	}
	
	
	@GetMapping("/fav/{userId}")
	public List<Movie> getAllFavoritesMovies(@PathVariable String userId) throws FavoritesEmptyException{
		return service.getAllFavoritesMovies(userId);
	}

	@DeleteMapping("/fav/{userId}/{movieId}")
	public void removeFavoritesMovie(@PathVariable String userId,@PathVariable int movieId) {
		service.removeFavoritesMovie(userId, movieId);
	}
	
}
