package com.cognizant.movieCruiser.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movieCruiser.dao.MovieDaoCollectionImpl;
import com.cognizant.movieCruiser.model.Movie;

@Service
public class MovieService {

	@Autowired
	private MovieDaoCollectionImpl moviedao;

	public List<Movie> getMovieListAdmin() {
		return moviedao.getMovieListAdmin();

	}

	public List<Movie> getMovieListCustomer() {
		List<Movie> list = moviedao.getMovieListCustomer();
		return list;
	}
	
	public void modifyMovie(Movie movie) {
		moviedao.modifyMovie(movie);
	}
	

}
