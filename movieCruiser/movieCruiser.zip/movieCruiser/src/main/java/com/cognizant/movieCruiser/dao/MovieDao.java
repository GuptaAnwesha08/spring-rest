package com.cognizant.movieCruiser.dao;

import java.util.List;

import com.cognizant.movieCruiser.model.Movie;

public interface MovieDao {

	 public List<Movie> getMovieListAdmin();
	 public List<Movie> getMovieListCustomer();
	// public Optional<Movie> findById(int id);
	public void modifyMovie(Movie movie);

		//public Movie getMovie(long movieId);
	 
	 public Movie getMovieById(int id);
	
}
